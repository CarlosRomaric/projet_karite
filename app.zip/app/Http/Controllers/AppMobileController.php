<?php

namespace App\Http\Controllers;

class AppMobileController extends Controller
{

    public function index()
    {
        return view('app-mobile.index');
    }

}
