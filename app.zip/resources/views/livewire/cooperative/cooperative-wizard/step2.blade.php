<div class="flex  place-items-center mb-5">

    <h4 class="text-2xl w-1/5">Informations sur le PCA</h4>
    <hr class="w-4/5 h-1 bg-amber-300 ">
</div>


<div class="flex">
    
    <div class="w1/2 mr-5">
        
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="president_nom">
                Nom du président
            </label>
            
            <input wire:model="president_nom" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="president_nom" type="text" placeholder="Nom"> 
        
        </div>
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="president_nom">
                Nom du président
            </label>
            
            <input wire:model="president_nom" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" id="president_nom" type="text" placeholder="Nom"> 
        
        </div>

    </div>
    <div class="w-1/2">

    </div>

</div>


